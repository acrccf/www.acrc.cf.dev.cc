<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'cfDBsy8mv');

/** MySQL database username */
define('DB_USER', 'cfDBsy8mv');

/** MySQL database password */
define('DB_PASSWORD', 'Ees2BMYhs0');

/** MySQL hostname */
define('DB_HOST', '127.0.0.1');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'o<Puf3^eL*qLc3,YF^rEjQ,vQAM^qEfQoV[-O8oZk|0kV[zN4vc0!VFzgB}grc0');
define('SECURE_AUTH_KEY',  'e]lW;+O5pa1_WhS_tH;M7rXj7<YI.qE6qbyXEyi2.fP{xL2Eye2.B}cJV>vJ4v');
define('LOGGED_IN_KEY',    's1sc}@[ZGzgsN4kRc0@RCaH+l6#iP#1~S9tal9#dKW]wK1lSd9|dO~pD[M2mX<yMX');
define('NONCE_KEY',        '_K5p-l5#WeL#sDO5lSa:-_dK-hsC[ZlSmTf$MXEubmE{emT.uEPAxamAmuL*P6Hc');
define('AUTH_SALT',        '$I3jQ,qyM3A$i3*{bIy.q|s@N4kwd:z|cJz|sC>4kR>z!UBJzk4!}jQ^}zJ0BvYtd');
define('SECURE_AUTH_SALT', 'hkC:hR[z|ZJ@k8|D]eqa]+P6xi6_WiS.tO5pW]+#aH_tD:hO_;~7,XI$j7,qX{yI');
define('LOGGED_IN_SALT',   '!N^r@N4kUg-l1_;eO~lxO5lwh1~OaH~l9KdOZ:-VGwh5!VGSX+PAub6.XiT.uH;m');
define('NONCE_SALT',       'YVv^Q7nzg0@>jQ^nzJgrYsZl5_[dK-htK1hs|1_-k4G1hR!sN4Gzk8|ZGeL*q+P6');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);define('FS_METHOD', 'direct');

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
